package com.anti.spring28Practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring28PracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
