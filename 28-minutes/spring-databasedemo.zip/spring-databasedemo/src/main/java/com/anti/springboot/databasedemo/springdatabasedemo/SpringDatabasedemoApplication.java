package com.anti.springboot.databasedemo.springdatabasedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDatabasedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDatabasedemoApplication.class, args);
	}

}
