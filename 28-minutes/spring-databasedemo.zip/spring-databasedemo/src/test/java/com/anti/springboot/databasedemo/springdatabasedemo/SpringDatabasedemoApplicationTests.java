package com.anti.springboot.databasedemo.springdatabasedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDatabasedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
