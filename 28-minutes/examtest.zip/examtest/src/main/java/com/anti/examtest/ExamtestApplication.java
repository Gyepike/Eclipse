package com.anti.examtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamtestApplication.class, args);
	}

}
