package com.anti.examtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamtestApplicationTests {

	@Test
	void contextLoads() {
	}

}
